A simple scenario inspired by Karel The Robot and modified by Thomas Kempe & David Tepaße

In diesem Szenario können verschiedene Roboter (Unterklassen von Roboter) erzeugt werden.
Mit Hilfe einiger Sensoren können diese Roboter auch komplexe Aufgaben erledigen.
Die Roboter können zudem Akkus aufnehmen und Schrauben ablegen.
