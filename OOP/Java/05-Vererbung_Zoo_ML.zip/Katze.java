public class Katze extends Laufend {

    public Katze( String pName ) {
        super(pName);
    }

    public void sagWas() {
        System.out.println("Ich bin eine Adler.");
        super.sagWas();
    }

}
