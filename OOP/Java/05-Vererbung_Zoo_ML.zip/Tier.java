public class Tier {

    private String name;

    public Tier( String pName ) {
        name = pName;
    }

    public void sagWas() {
        System.out.println("Mein Name ist " + name);
    }

}
