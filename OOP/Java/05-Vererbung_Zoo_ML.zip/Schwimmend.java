public class Schwimmend extends Tier {

    public Schwimmend( String pName ) {
        super(pName);
    }

    public void sagWas() {
        super.sagWas();
        System.out.println("Ich schwimme im Wasser.");
    }

}
