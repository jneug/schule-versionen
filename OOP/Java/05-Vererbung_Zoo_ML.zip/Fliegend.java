public class Fliegend extends Tier {

    public Fliegend( String pName ) {
        super(pName);
    }

    public void sagWas() {
        super.sagWas();
        System.out.println("Ich fliege in der Luft.");
    }

}
