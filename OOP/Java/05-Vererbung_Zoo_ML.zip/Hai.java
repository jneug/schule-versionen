public class Hai extends Schwimmend {

    public Hai( String pName ) {
        super(pName);
    }

    public void sagWas() {
        System.out.println("Ich bin ein Hai.");
        super.sagWas();
    }

}
