public class Adler extends Fliegend {

    public Adler( String pName ) {
        super(pName);
    }

    public void sagWas() {
        System.out.println("Ich bin ein Adler.");
        super.sagWas();
    }

}
