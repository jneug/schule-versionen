public class Falke extends Tier {

    public Falke( String pName ) {
        super(pName);
    }

    public void sagWas() {
        System.out.println("Ich bin ein Falke.");
        super.sagWas();
    }

}
