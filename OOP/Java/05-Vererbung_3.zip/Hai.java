public class Hai extends Tier {

    public Hai( String pName ) {
        super(pName);
    }

    public void sagWas() {
        System.out.println("Ich bin ein Hai.");
        super.sagWas();
    }

}
