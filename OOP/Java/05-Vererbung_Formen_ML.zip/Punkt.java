

public class Punkt {

    private int x;

    private int y;

    public Punkt( int pX, int pY ) {
        x = pX;
        y = pY;
    }

    public void setX( int pX ) {
        x = pX;
    }

    public int getX() {
        return x;
    }

    public void setY( int pY ) {
        y = pY;
    }

    public int getY() {
        return y;
    }

}
