public class AdtDojo {

}
